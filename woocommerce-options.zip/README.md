# WooCommerce Custom Options

Plugin simple para personalizar opciones de WooCommerce relacionadas con productos relacionados, cantidades mínimas y botones personalizados.

## Características

### Productos Relacionados
- **Relacionar por categorías, etiquetas o campo personalizado**: Elige cómo se relacionan los productos
- **Campo RELATED personalizado**: Define grupos de productos relacionados con etiquetas personalizadas
- **Cantidad configurable**: Define cuántos productos relacionados mostrar (1-12)
- **Columnas configurables**: Elige el número de columnas para la cuadrícula (1-6)
- **Soporte Quick Edit y Bulk Edit**: Edita el campo RELATED rápidamente

### Cantidad Mínima
- **Cantidad mínima por producto**: Define la cantidad mínima que debe comprar el cliente
- **Incremento de cantidad**: Define el paso de incremento/decremento (ej: de 5 en 5)
- **Compatible con productos simples y variables**: Funciona en todos los tipos de producto
- **Hereda de producto padre**: Las variaciones pueden heredar la cantidad mínima del producto variable

### Botones Personalizados de Productos
- **Múltiples botones**: Añade uno o más botones personalizados por producto
- **Enlaces a productos**: Cada botón puede enlazar a cualquier otro producto de tu tienda
- **Texto personalizable**: Define el texto específico para cada botón
- **Clases CSS automáticas**: Cada botón recibe una clase CSS basada en su texto para personalización avanzada
- **Posición estratégica**: Los botones aparecen antes del formulario de compra
- **Interfaz intuitiva**: Gestor visual de botones en el panel de administración
- **Diseño responsive**: Se adapta perfectamente a dispositivos móviles

## Configuración

### Productos Relacionados
Ve a **WooCommerce > Ajustes > Productos** y encontrarás una nueva sección "Productos Relacionados" con las opciones:

1. **Relacionar productos por**:
   - Solo categorías
   - Solo etiquetas
   - Categorías y etiquetas
   - Campo personalizado RELATED
2. **Número de productos** - Por defecto 4
3. **Columnas** - Por defecto 4

### Campo RELATED
En la edición de cada producto (pestaña General), encontrarás:
- **RELATED**: Etiqueta personalizada para agrupar productos relacionados (ej: "verano", "boda", "pack-especial")

### Cantidad Mínima
En la edición de cada producto (pestaña General), encontrarás:
- **Cantidad Mínima**: Define la cantidad mínima de compra (déjalo vacío para 1 por defecto)
- **Incremento de Cantidad**: Define en cuántas unidades aumenta/disminuye cada clic (ej: 5 para incrementos de 5 en 5)

### Botones Personalizados de Productos
En la edición de cada producto (pestaña General), encontrarás la sección "Botones de Productos Personalizados":

1. **Añadir botones**: Haz clic en "Añadir Botón" para crear un nuevo botón
2. **Configurar cada botón**:
   - **Producto de destino**: Busca y selecciona el producto al que enlazará el botón
   - **Texto del botón**: Escribe el texto que aparecerá en el botón (ej: "Ver talla grande", "Combina con este producto", "Ver pack completo")
3. **Múltiples botones**: Puedes añadir tantos botones como necesites
4. **Eliminar botones**: Usa el botón "Eliminar" en cada botón para quitarlo

**Ejemplos de uso**:
- Enlazar a tallas diferentes del mismo producto
- Sugerir productos complementarios
- Promocionar packs o combos
- Dirigir a versiones premium o alternativas

Los botones aparecerán automáticamente antes del formulario de selección de variaciones o del botón de añadir al carrito.

## Instalación

1. Sube la carpeta `woocommerce-options` a `/wp-content/plugins/`
2. Activa el plugin desde el menú 'Plugins' en WordPress
3. Configura las opciones en WooCommerce > Ajustes > Productos

## Requisitos

- WordPress 5.8 o superior
- WooCommerce 5.0 o superior
- PHP 7.4 o superior
