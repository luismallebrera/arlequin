# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

## [1.5.1] - 2025-12-23

### Añadido
- **Nueva pestaña dedicada "Botones"** en los datos del producto para gestionar botones personalizados
- **Clases CSS automáticas** basadas en el texto del botón (formato: `wc-button-{texto-sanitizado}`)
- Ejemplos de personalización CSS en el archivo frontend-buttons.css
- Icono personalizado para la pestaña de botones
- Archivo CSS específico para el admin (`assets/css/admin-buttons.css`)
- Declaración de compatibilidad con HPOS (High-Performance Order Storage)
- Declaración de compatibilidad con Cart & Checkout Blocks
- Logs de debug detallados para el guardado de botones personalizados
- Archivo DEBUG-INSTRUCCIONES.md con guía de troubleshooting
- Documentación ampliada sobre personalización de estilos por tipo de botón

### Modificado
- Movidos los campos de botones de la pestaña General a su propia pestaña dedicada
- Mejorado el diseño visual de los campos de botones con CSS limpio
- Actualizado "WC tested up to" a 9.5
- Mejorada la validación de seguridad en el guardado de botones (nonce, permisos, autosave)
- Eliminados estilos inline en favor de CSS externo

### Corregido
- Problema con el guardado de botones personalizados (eliminado hook duplicado)

## [1.5.0] - 2025-12-23

### Añadido
- **Botones Personalizados de Productos**: Nueva funcionalidad para añadir botones con enlaces a otros productos
  - Interfaz intuitiva en el panel de administración
  - Múltiples botones por producto
  - Selector de productos con búsqueda integrada de WooCommerce
  - Texto personalizable para cada botón
  - Los botones aparecen antes del formulario de variaciones/añadir al carrito
  - Diseño responsive con CSS optimizado
  - Scripts JavaScript para gestión dinámica de botones en admin
  - Archivos: `assets/js/admin-buttons.js` y `assets/css/frontend-buttons.css`
- Documentación completa de la nueva funcionalidad en README

### Modificado
- Actualizada la descripción del plugin para incluir botones personalizados
- Mejorado el README con instrucciones detalladas de configuración

## [1.4.0] - 2025-12-23

### Eliminado
- **Atributos Condicionales**: Se ha eliminado completamente la funcionalidad de atributos condicionales
  - Eliminado el archivo `ATRIBUTOS-CONDICIONALES.md`
  - Eliminado el archivo `assets/js/conditional-attributes.js`
  - Eliminado el archivo `assets/css/conditional-attributes.css`
  - Eliminado el método `enqueue_conditional_attributes_scripts()`
  - Actualizada la descripción del plugin

## [1.3.0] - 2025-12-23

### Añadido
- **Atributos Condicionales**: Nueva funcionalidad para mostrar/ocultar atributos dinámicamente
  - Atributo maestro: DISEÑO ETIQUETA (MOTIVO, VICHY, CORONA)
  - Atributos dependientes: MOTIVO (6 opciones) y COLOR VICHY (5 colores)
  - Transiciones suaves CSS para mejor UX
  - Compatible con productos simples y variables
  - Scripts JavaScript optimizados con manejo de eventos
- **Incremento de Cantidad**: Nuevo campo para definir el paso de incremento/decremento
  - Campo `_quantity_step` en la edición de productos
  - Compatible con productos simples y variables
  - Las variaciones heredan del producto padre si no tienen valor propio
- Documentación técnica completa en `ATRIBUTOS-CONDICIONALES.md`
- Archivos CSS y JS en directorio `assets/`

### Modificado
- Actualizada la descripción del plugin para incluir atributos condicionales
- Mejorado el README con instrucciones de configuración de atributos condicionales
- Optimizado el código de cantidad mínima para incluir soporte de incrementos

## [1.2.0] - 2024

### Añadido
- **Cantidad Mínima por Producto**: Define la cantidad mínima que el cliente debe comprar
  - Campo `_min_quantity` en la edición de productos
  - Compatible con productos simples y variables
  - Las variaciones pueden heredar del producto padre
  - Validación en el frontend

### Modificado
- Mejorado el soporte para variaciones en el campo RELATED
- Optimizaciones en el código JavaScript del Quick Edit

## [1.1.0] - 2024

### Añadido
- **Soporte Quick Edit y Bulk Edit** para el campo RELATED
  - Edición rápida desde la lista de productos
  - Edición masiva con opción de borrar
  - JavaScript para prellenar valores en Quick Edit

### Modificado
- Mejorada la interfaz de usuario en la edición de productos

## [1.0.0] - 2024

### Añadido
- **Productos Relacionados Personalizables**:
  - Opciones en WooCommerce > Ajustes > Productos
  - Relacionar por categorías, etiquetas o ambos
  - Número configurable de productos (1-12)
  - Columnas configurables (1-6)
- **Campo RELATED Personalizado**:
  - Campo de texto en la edición de productos
  - Agrupa productos con la misma etiqueta
  - Opción "Campo personalizado RELATED" en ajustes
- Configuración inicial del plugin
- Verificación de dependencia de WooCommerce
- Textos traducibles preparados

### Seguridad
- Escapado de todas las salidas HTML
- Sanitización de todos los inputs
- Verificación de permisos en guardado
- Protección contra acceso directo
